/********************* RESOURCE STRINGS ***********************/
DECLARE @stringId AS int;
DECLARE @cultureId AS int;
DECLARE @cultureCode AS nvarchar(50);

-- Change value of this parameter if your default UI culture is not 'en-US' (see details in hotfix instructions)
SET @cultureCode = 'en-US';

-- Get culture ID
SET @cultureId = (SELECT UICultureID FROM [CMS_UICulture] WHERE UICultureCode=@cultureCode);
IF  @cultureId IS NULL
BEGIN
  SET @cultureId = (SELECT UICultureID FROM [CMS_UICulture] WHERE UICultureCode='en-US');
END

SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'board.messageedit.alreadyrated' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('board.messageedit.alreadyrated'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'You''ve already rated.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'doctype.ecommerce.mappingwarning' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('doctype.ecommerce.mappingwarning'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'These settings provide backward compatibility after upgrading or importing from older versions.</br> It is not necessary to use mapping in current version of CMS.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'general.actionfinished' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('general.actionfinished'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Action finished successfully')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'general.copyfiles.precompiled' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('general.copyfiles.precompiled'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Cannot copy physical files in precompiled website.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Update macro signatures')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.currentsaltisconnectionstring' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.currentsaltisconnectionstring'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(Current salt is a connection string, not shown for security reasons)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.currentsaltiscustomvalue' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.currentsaltiscustomvalue'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(Current salt is a custom value, not shown for security reasons)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.description' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.description'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Whenever a user saves a macro expression, the system automatically adds a security signature containing the user name of the macro''s author and a hash of the expression. The hash function also appends a <strong>salt</strong> to the input. By default, the system uses the application''s database connection string as the salt. 
<br /><br />
If your application''s hash salt value changes, the security signatures of existing macro expressions become invalid. This may lead to problems with unresolved macros in certain scenarios:
<ul>
<li>
The connection string of your application has changed, e.g. when moving to a different server or after setting a new database password.
</li><li>
You are using content staging to transfer data containing macros to another instance with a different connection string.
</li><li>
You have set a new custom salt via the <strong>CMSHashStringSalt</strong> web.config key.
</li></ul>
To re-sign all occurrences of macros in the system, enter the appropriate hash salt values and click <strong>Update macro signatures</strong>.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.newsalt' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.newsalt'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'New salt')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.newsaltempty' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.newsaltempty'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter the new salt.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.oldsalt' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.oldsalt'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Old salt')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.oldsaltempty' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.oldsaltempty'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter the old salt.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.processing' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.processing'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Processing ''{0}'' objects ...')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.refreshall' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.refreshall'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Sign all macros')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.refreshalldescription' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.refreshalldescription'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'(Re-signs all macros based on the current user)')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.refreshalltooltip' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.refreshalltooltip'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'If enabled, the macro re-signing process skips the signature integrity check, so you do not need to enter the old salt value. Check this option to re-sign all macros, including those that are unsigned or have invalid signatures.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'macros.refreshsecurityparams.usecurrentsalt' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('macros.refreshsecurityparams.usecurrentsalt'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Use the current salt')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'mem.facebook.enterapikey' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('mem.facebook.enterapikey'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter an API key.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'mem.facebook.enterappsecret' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('mem.facebook.enterappsecret'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter an application secret.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'mem.facebook.enterpageid' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('mem.facebook.enterpageid'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Please enter a Facebook Page ID.')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'objecttype.om_membershipsubscriber' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('objecttype.om_membershipsubscriber'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Contact-subscriber relation')
END


SET @stringId = (SELECT StringID FROM [CMS_ResourceString] LEFT JOIN [CMS_ResourceTranslation] ON StringID=TranslationStringID WHERE StringKey = N'settingskey.screenlockinterval.description' AND TranslationUICultureID = @cultureId);
IF  @stringId IS NULL
BEGIN
-- Insert resource string
INSERT INTO [CMS_ResourceString]
           ([StringKey]
           ,[StringIsCustom]
           ,[StringLoadGeneration])
     VALUES
           ('settingskey.screenlockinterval.description'
           ,0
           ,0)

SET @stringId = scope_identity();

-- Insert translation
INSERT INTO [CMS_ResourceTranslation]
           ([TranslationStringID]
          ,[TranslationUICultureID]
           ,[TranslationText])
     VALUES
           (@stringId
           ,@cultureId
           ,'Time (in minutes) that has to pass before the screen is locked. This value has to be greater than 0 and lower than session timeout.')
END


GO
/*********************  END RESOURCE STRINGS ***********************/

-- B5433 - Team development - My desk > Checked out objects - edit action for email template is missing
GO
UPDATE [CMS_Class] SET [ClassEditingPageURL] = N'~/CMSModules/EmailTemplates/Pages/Frameset.aspx?templateid={%EditedObject.ID%}&&tabmode=1&editonlycode=1' WHERE [ClassName] = N'cms.emailtemplate'
GO

-- B5477 - [Team development] - UIForm checks out all new objects, not only objects that support locking
GO
DELETE FROM [CMS_ObjectSettings] WHERE [ObjectSettingsObjectType] NOT IN ('cms.layout','cms.templatedevicelayout','cms.pagetemplate','cms.emailtemplate','cms.transformation','cms.cssstylesheet','cms.webpartcontainer','cms.webpartlayout')
GO

-- B5563 - [General] - SQL exception while deleting module
GO
ALTER PROCEDURE [Proc_CMS_Resource_RemoveDependencies]
	@ID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION;    
    DELETE FROM [CMS_ResourceSite] WHERE ResourceID = @ID;
	
	-- Permissions
    DELETE FROM [Forums_ForumRoles]				WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [CMS_RolePermission]			WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [Community_GroupRolePermission]	WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [Media_LibraryRolePermission]	WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
    DELETE FROM [CMS_WidgetRole]				WHERE PermissionID IN (SELECT PermissionID FROM [CMS_Permission] WHERE ResourceID = @ID);
	DELETE FROM [CMS_Permission] WHERE ResourceID = @ID;

    -- UI elements
    DELETE FROM [CMS_RoleUIElement] WHERE ElementID IN (SELECT ElementID FROM CMS_UIElement WHERE ElementResourceID = @ID);
    DELETE FROM [CMS_UIElement] WHERE ElementResourceID = @ID;
    
    UPDATE [CMS_WebPart] SET WebPartResourceID = NULL WHERE WebPartResourceID = @ID;
    UPDATE [CMS_FormUserControl] SET UserControlResourceID = NULL WHERE UserControlResourceID = @ID;
    UPDATE [CMS_InlineControl] SET ControlResourceID = NULL WHERE ControlResourceID = @ID;
    UPDATE [CMS_ScheduledTask] SET TaskResourceID = NULL WHERE TaskResourceID = @ID;
	UPDATE [CMS_WorkflowAction] SET ActionResourceID = NULL WHERE ActionResourceID = @ID;
        
	COMMIT TRANSACTION;
END
GO


-- B5621 - [Web parts] - Google analytics doesn't support some multiple subdomain scenarios
GO
UPDATE [CMS_WebPart]
SET [WebPartProperties] = '<form><category name="Google Analytics Settings" visible="True" /><field column="TrackingCode" fieldcaption="Tracking code" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="20" fielddescription="This code is obtained from the Google Analytics service at www.google.com/analytics." publicfield="false" spellcheck="false" guid="47bb33c6-3432-4fee-8dd2-204d2552ad5d" visibility="none"><settings><controlname>textboxcontrol</controlname></settings></field><field column="TrackingType" fieldcaption="Tracking type" visible="true" defaultvalue="0" columntype="integer" fieldtype="CustomUserControl" allowempty="true" fielddescription="Type of the tracking depending on the domain model." publicfield="false" spellcheck="false" guid="0b69524d-3de0-440d-9c07-ec39ab5ecae5" visibility="none"><settings><controlname>radiobuttonscontrol</controlname><RepeatDirection>vertical</RepeatDirection><Options>0; Single domain (e.g. only www.example.com)
1; One domain with multiple subdomains (e.g. sub1.example.com, sub2.example.com, sub3.example.com)
2; Multiple top-level domains (e.g. www.example.com, www.example.net, www.example.org)</Options></settings></field><field column="MainWebsiteDomain" fieldcaption="Website main domain" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" fielddescription="Use this property to specify a custom domain name used for tracking purposes in non-trivial scenarios. For example, if you want to track visits to &quot;my.first.example.com&quot; and &quot;my.second.example.com&quot;, which  are both subdomains of &quot;example.com&quot;, fill in &quot;example.com&quot;. If you leave the property empty, the web part will use the current domain." publicfield="false" guid="9b514025-ca06-44d1-8f9a-c8a503ef8926" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field><field column="UseAsyncScript" fieldcaption="Use asynchronous script" visible="true" defaultvalue="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" fielddescription="Indicates if asynchronous variant of Google analytics script should be used." publicfield="false" spellcheck="false" guid="3f158398-bbf7-4061-8131-5777c6b2b04f" visibility="none"><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
WHERE [WebPartName]= N'GoogleAnalytics'
GO


-- B5562 - Custom table item selector form control in not working
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 2
BEGIN
	UPDATE [CMS_FormUserControl] SET UserControlParameters = '<form><field column="CustomTable" fieldcaption="Custom table" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" fielddescription="Selects from which custom table the items will be offered." publicfield="false" guid="ecbd7716-cf7f-4b30-a62d-112b2c301a95" visibility="none"><settings><controlname>customtableselector</controlname></settings></field><field column="DisplayNameFormat" fieldcaption="Format of the display name" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="400" fielddescription="Determines the format of the item names displayed in the selector. You can use macros in format {%ColumnName%} to dynamically retrieve values of specific items." publicfield="false" guid="610bf2db-dffb-446f-b9e8-a2b45cdb1eee" visibility="none"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode><Trim>False</Trim><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="ReturnColumnName" fieldcaption="Name of the value column" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" fielddescription="Specifies the column from which the value stored by the selector will be loaded. This must be a unique identifier for the given custom table." publicfield="false" guid="add37892-aca1-403c-8714-444fb950765a" visibility="none"><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>textboxcontrol</controlname></settings></field></form>'
		WHERE UserControlCodeName = 'CustomTableItemSelector'
END
GO

-- B5657 - Facebook - Update setting (from global setting to site setting)
GO
IF (SELECT TOP 1 KeyIsGlobal FROM CMS_SettingsKey WHERE KeyName LIKE 'CMSFacebookConnectApiKey') = 1
BEGIN
	DECLARE @categoryID int;
	DECLARE @currentSiteID int;
	DECLARE @counter int;
	DECLARE @rowCount int;
	DECLARE @siteTable TABLE (SiteID INT NOT NULL);


	INSERT INTO @siteTable SELECT SiteID FROM CMS_Site ORDER BY SiteID ASC;
	SET @rowCount = (SELECT COUNT(SiteID) FROM @siteTable);
	SET @counter = 0;
	SET @currentSiteID = (SELECT TOP 1 SiteID FROM @siteTable ORDER BY SiteID ASC);
	SET @categoryID = (SELECT TOP 1 KeyCategoryID FROM CMS_SettingsKey WHERE KeyName LIKE 'CMSFacebookConnectApiKey');

	UPDATE CMS_SettingsKey SET
		KeyIsGlobal = 0
	WHERE KeyName LIKE 'CMSFacebookConnectApiKey';

	WHILE @counter < @rowCount
	BEGIN
		INSERT INTO CMS_SettingsKey
		(KeyName, KeyDisplayName, KeyDescription, KeyType, KeyCategoryID, KeyGUID, KeyLastModified, KeyOrder, SiteID)
		VALUES ('CMSFacebookConnectApiKey', '{$settingskey.cmsfacebookconnectapikey$}', '{$settingskey.cmsfacebookconnectapikey.description$}',
		'string', @categoryID, NEWID(), GETDATE(), 1, @currentSiteID );
		DELETE FROM @siteTable WHERE SiteID = @currentSiteID;
		SET @currentSiteID = (SELECT TOP 1 SiteID FROM @siteTable ORDER BY SiteID ASC);
		SET @counter = @counter + 1    
	END;
END;
GO

--B5726 - Route documen aliases are not redirected to the main alias
DROP VIEW [View_CMS_DocumentAlias_Joined]
GO

CREATE VIEW [View_CMS_DocumentAlias_Joined]
AS
SELECT     CMS_Tree.NodeAliasPath, CMS_DocumentAlias.AliasNodeID, CMS_DocumentAlias.AliasCulture, CMS_DocumentAlias.AliasURLPath, 
                      CMS_DocumentAlias.AliasSiteID, CMS_DocumentAlias.AliasActionMode
FROM         CMS_DocumentAlias INNER JOIN
                      CMS_Tree ON CMS_DocumentAlias.AliasNodeID = CMS_Tree.NodeID
GO

--B5756 - Update stored procedure Proc_CMS_Class_Insert
GO
ALTER PROCEDURE [Proc_CMS_Class_Insert]
	@ClassID int = NULL,
    @ClassDisplayName nvarchar(100),
    @ClassName nvarchar(100),
    @ClassUsesVersioning bit,
    @ClassIsDocumentType bit,
    @ClassIsCoupledClass bit,
    @ClassXmlSchema ntext,
    @ClassFormDefinition ntext,
    @ClassNewPageUrl nvarchar(450),
    @ClassEditingPageUrl nvarchar(450),
    @ClassListPageUrl nvarchar(450),
    @ClassNodeNameSource nvarchar(100),
    @ClassTableName nvarchar(100),
    @ClassViewPageUrl nvarchar(450),
    @ClassPreviewPageUrl nvarchar(450),
    @ClassFormLayout ntext,
    @ClassShowAsSystemTable bit,
    @ClassUsePublishFromTo bit,
    @ClassShowTemplateSelection bit,
    @ClassSKUMappings ntext,
    @ClassIsMenuItemType bit,
    @ClassNodeAliasSource nvarchar(100),
    @ClassDefaultPageTemplateID int,    
    @ClassSKUDefaultDepartmentID int,
    @ClassSKUDefaultDepartmentName nvarchar(200),
    @ClassLastModified datetime,
    @ClassGUID uniqueidentifier,
    @ClassCreateSKU int,
    @ClassIsProduct bit,    
    @ClassIsCustomTable bit,
    @ClassShowColumns nvarchar(1000),
    @ClassLoadGeneration int,
	@ClassSearchTitleColumn nvarchar(200),
	@ClassSearchContentColumn nvarchar(200),
	@ClassSearchImageColumn nvarchar(200),
    @ClassSearchCreationDateColumn nvarchar(200),
    @ClassSearchSettings ntext,
    @ClassInheritsFromClassID int,
    @ClassSearchEnabled bit,
    @ClassContactMapping ntext,
    @ClassContactOverwriteEnabled bit,
    @ClassSKUDefaultProductType nvarchar(50),
    @ClassConnectionString nvarchar(100),
    @ClassIsProductSection bit,
    @ClassPageTemplateCategoryID int
AS
BEGIN
INSERT INTO [CMS_Class] (
    [ClassDisplayName],
    [ClassName],
    [ClassUsesVersioning],
    [ClassIsDocumentType],
    [ClassIsCoupledClass],
    [ClassXmlSchema],
    [ClassFormDefinition],
    [ClassNewPageUrl],
    [ClassEditingPageUrl],
    [ClassListPageUrl],
    [ClassNodeNameSource],    
    [ClassTableName],
    [ClassViewPageUrl],
    [ClassPreviewPageUrl],
    [ClassFormLayout],
    [ClassShowAsSystemTable],
    [ClassUsePublishFromTo],
    [ClassShowTemplateSelection],
    [ClassSKUMappings],
    [ClassIsMenuItemType],
    [ClassNodeAliasSource],
    [ClassDefaultPageTemplateID],    
    [ClassSKUDefaultDepartmentID],
    [ClassSKUDefaultDepartmentName],
    [ClassLastModified],
    [ClassGUID],
    [ClassCreateSKU],
    [ClassIsProduct],    
    [ClassIsCustomTable],
    [ClassShowColumns],
    [ClassLoadGeneration],
	[ClassSearchTitleColumn],
	[ClassSearchContentColumn],
	[ClassSearchImageColumn],
    [ClassSearchCreationDateColumn],
    [ClassSearchSettings],
    [ClassInheritsFromClassID],
    [ClassSearchEnabled],
    [ClassContactMapping],
    [ClassContactOverwriteEnabled],
    [ClassSKUDefaultProductType],
    [ClassConnectionString],
    [ClassIsProductSection],
    [ClassPageTemplateCategoryID]
)
VALUES (
    @ClassDisplayName, 
    @ClassName, 
    @ClassUsesVersioning, 
    @ClassIsDocumentType, 
    @ClassIsCoupledClass, 
    @ClassXmlSchema, 
    @ClassFormDefinition, 
    @ClassNewPageUrl, 
    @ClassEditingPageUrl, 
    @ClassListPageUrl, 
    @ClassNodeNameSource, 
    @ClassTableName,
    @ClassViewPageUrl,
    @ClassPreviewPageUrl,
    @ClassFormLayout,
    @ClassShowAsSystemTable,
    @ClassUsePublishFromTo,
    @ClassShowTemplateSelection,
    @ClassSKUMappings,
    @ClassIsMenuItemType,
    @ClassNodeAliasSource,
    @ClassDefaultPageTemplateID,    
    @ClassSKUDefaultDepartmentID,
    @ClassSKUDefaultDepartmentName,
    @ClassLastModified,
    @ClassGUID,
    @ClassCreateSKU,
    @ClassIsProduct,    
    @ClassIsCustomTable,
    @ClassShowColumns,
    @ClassLoadGeneration,
	@ClassSearchTitleColumn,
	@ClassSearchContentColumn,
	@ClassSearchImageColumn,
    @ClassSearchCreationDateColumn,
    @ClassSearchSettings,
    @ClassInheritsFromClassID,
    @ClassSearchEnabled,
    @ClassContactMapping,
    @ClassContactOverwriteEnabled,
    @ClassSKUDefaultProductType,
    @ClassConnectionString,
    @ClassIsProductSection,
    @ClassPageTemplateCategoryID
)
SELECT SCOPE_IDENTITY()
END
GO

--B5756 - Update stored procedure Proc_CMS_Class_Update
GO
ALTER PROCEDURE [Proc_CMS_Class_Update]
	@ClassID int,
    @ClassDisplayName nvarchar(100),
    @ClassName nvarchar(100),
    @ClassUsesVersioning bit,
    @ClassIsDocumentType bit,
    @ClassIsCoupledClass bit,
    @ClassXmlSchema ntext,
    @ClassFormDefinition ntext,
    @ClassNewPageUrl nvarchar(450),
    @ClassEditingPageUrl nvarchar(450),
    @ClassListPageUrl nvarchar(450),
    @ClassNodeNameSource nvarchar(100),
    @ClassTableName nvarchar(100),
    @ClassViewPageUrl nvarchar(450),
    @ClassPreviewPageUrl nvarchar(450),
    @ClassFormLayout ntext,
    @ClassShowAsSystemTable bit,
    @ClassUsePublishFromTo bit,
    @ClassShowTemplateSelection bit,
    @ClassSKUMappings ntext,
    @ClassIsMenuItemType bit,
    @ClassNodeAliasSource nvarchar(100),
    @ClassDefaultPageTemplateID int,
    @ClassSKUDefaultDepartmentID int,
    @ClassSKUDefaultDepartmentName nvarchar(200),
    @ClassLastModified datetime,
    @ClassGUID uniqueidentifier,
    @ClassCreateSKU int,
    @ClassIsProduct bit,
    @ClassIsCustomTable bit,
    @ClassShowColumns nvarchar(1000),
    @ClassLoadGeneration int,
	@ClassSearchTitleColumn nvarchar(200),
	@ClassSearchContentColumn nvarchar(200),
	@ClassSearchImageColumn nvarchar(200),
    @ClassSearchCreationDateColumn nvarchar(200),
    @ClassSearchSettings ntext,
    @ClassInheritsFromClassID int,
    @ClassSearchEnabled bit,
    @ClassContactMapping ntext,
    @ClassContactOverwriteEnabled bit,
    @ClassSKUDefaultProductType nvarchar(50),
    @ClassConnectionString nvarchar(100),
    @ClassIsProductSection bit,
    @ClassPageTemplateCategoryID int
AS
BEGIN
UPDATE [CMS_Class] 
SET 
    ClassDisplayName = @ClassDisplayName,
    ClassName = @ClassName,
    ClassUsesVersioning = ClassUsesVersioning,
    ClassIsDocumentType = @ClassIsDocumentType,
    ClassIsCoupledClass = @ClassIsCoupledClass,
    ClassXmlSchema = @ClassXmlSchema,
    ClassFormDefinition = @ClassFormDefinition,
    ClassNewPageUrl = @ClassNewPageUrl,
    ClassEditingPageUrl = @ClassEditingPageUrl,
    ClassListPageUrl = @ClassListPageUrl,
    ClassNodeNameSource = @ClassNodeNameSource,
    ClassTableName = @ClassTableName,
    ClassViewPageUrl = @ClassViewPageUrl,
    ClassPreviewPageUrl = @ClassPreviewPageUrl,
    ClassFormLayout = @ClassFormLayout,
    ClassShowAsSystemTable = @ClassShowAsSystemTable,
    ClassUsePublishFromTo = @ClassUsePublishFromTo,
    ClassShowTemplateSelection = @ClassShowTemplateSelection,
    ClassSKUMappings = @ClassSKUMappings,
    ClassIsMenuItemType = @ClassIsMenuItemType,
    ClassNodeAliasSource = @ClassNodeAliasSource,
    ClassDefaultPageTemplateID = @ClassDefaultPageTemplateID, 
    ClassSKUDefaultDepartmentID = @ClassSKUDefaultDepartmentID,
    ClassSKUDefaultDepartmentName = @ClassSKUDefaultDepartmentName,
    ClassLastModified = @ClassLastModified,
    ClassGUID = @ClassGUID,
    ClassCreateSKU = @ClassCreateSKU,
    ClassIsProduct = @ClassIsProduct,
    ClassIsCustomTable = @ClassIsCustomTable,
    ClassShowColumns = @ClassShowColumns,
    ClassLoadGeneration = @ClassLoadGeneration,
    ClassSearchTitleColumn = @ClassSearchTitleColumn,
    ClassSearchContentColumn = @ClassSearchContentColumn,
    ClassSearchImageColumn = @ClassSearchImageColumn,
    ClassSearchCreationDateColumn = @ClassSearchCreationDateColumn,
    ClassSearchSettings = @ClassSearchSettings,
    ClassInheritsFromClassID = @ClassInheritsFromClassID,
    ClassSearchEnabled = @ClassSearchEnabled,
    ClassContactMapping = @ClassContactMapping,
    ClassContactOverwriteEnabled = @ClassContactOverwriteEnabled,
    ClassSKUDefaultProductType = @ClassSKUDefaultProductType,
    ClassConnectionString = @ClassConnectionString,
    ClassIsProductSection = @ClassIsProductSection,
    ClassPageTemplateCategoryID = @ClassPageTemplateCategoryID
WHERE
    ClassID = @ClassID
END
GO

-- B5756 - Update stored procedures for ordering attachment history
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_InitAttachmentOrders]
@AttachmentGUID uniqueidentifier,
@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);

	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Declare the selection table */
	DECLARE @attachmentTable TABLE (
		AttachmentHistoryID int NOT NULL,
		AttachmentName nvarchar(255) NOT NULL,
		AttachmentOrder int NULL
		
	);
	
	/* Get the grouped or unsorted attachments */
	IF @AttachmentGroupGUID IS NOT NULL
		INSERT INTO @attachmentTable SELECT AttachmentHistoryID, AttachmentName,  AttachmentOrder FROM CMS_AttachmentHistory WHERE  AttachmentGroupGUID = @AttachmentGroupGUID AND AttachmentDocumentID=@AttachmentDocumentID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE 
		INSERT INTO @attachmentTable SELECT AttachmentHistoryID, AttachmentName,  AttachmentOrder FROM CMS_AttachmentHistory WHERE  AttachmentGroupGUID IS NULL AND AttachmentDocumentID=@AttachmentDocumentID AND AttachmentIsUnsorted=1 AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	
	
	
	
	/* Declare the cursor to loop through the table */
	DECLARE @attachmentCursor CURSOR;
    SET @attachmentCursor = CURSOR FOR SELECT AttachmentHistoryID, AttachmentName, AttachmentOrder FROM @attachmentTable ORDER BY AttachmentOrder, AttachmentName, AttachmentHistoryID;
    
	/* Assign the numbers to the attachments */
	DECLARE @currentIndex int, @currentAttachmentOrder int, @currentAttachmentHistoryID int;
	SET @currentIndex = 1;
	
	DECLARE @currentAttachmentName nvarchar(255);
	
	/* Loop through the table */
	OPEN @attachmentCursor
	FETCH NEXT FROM @attachmentCursor INTO @currentAttachmentHistoryID,@currentAttachmentName, @currentAttachmentOrder;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		/* Set the attachments' index if different */
		IF @currentAttachmentOrder IS NULL OR @currentAttachmentOrder <> @currentIndex
			UPDATE CMS_AttachmentHistory SET AttachmentOrder = @currentIndex WHERE AttachmentHistoryID = @currentAttachmentHistoryID;
		/* Get next record */
		SET @currentIndex = @currentIndex + 1;
		FETCH NEXT FROM @attachmentCursor INTO @currentAttachmentHistoryID,@currentAttachmentName, @currentAttachmentOrder;
	END
	CLOSE @attachmentCursor;
	DEALLOCATE @attachmentCursor;
END
GO
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_MoveAttachmentDown]
	@AttachmentGUID uniqueidentifier,
	@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	DECLARE @MaxAttachmentOrder int
	IF @AttachmentGroupGUID IS NOT NULL
		SET @MaxAttachmentOrder = (SELECT TOP 1 AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)) ORDER BY AttachmentOrder DESC);
	ELSE
		SET @MaxAttachmentOrder = (SELECT TOP 1 AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)) ORDER BY AttachmentOrder DESC);		
	
	/* Move the next attachment(s) up */	
	IF @AttachmentGroupGUID IS NOT NULL
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) + 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) + 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
		
	/* Move the current attachment down */
	UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentHistoryID = @AttachmentHistoryID AND AttachmentOrder < @MaxAttachmentOrder
END
GO
ALTER PROCEDURE [Proc_CMS_AttachmentHistory_MoveAttachmentUp]
	@AttachmentGUID uniqueidentifier,
	@VersionHistoryID int
AS
BEGIN
	/* Get Attachment ID */
	DECLARE @AttachmentHistoryID int;
	SET @AttachmentHistoryID = (SELECT TOP 1 AttachmentHistoryID FROM CMS_AttachmentHistory WHERE (AttachmentGUID = @AttachmentGUID) AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID)));

	/* Get attachment's document ID */
	DECLARE @AttachmentDocumentID int;
	SET @AttachmentDocumentID = (SELECT TOP 1 AttachmentDocumentID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Get ID of group */
	DECLARE @AttachmentGroupGUID uniqueidentifier;
	SET @AttachmentGroupGUID = (SELECT TOP 1 AttachmentGroupGUID FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID);
	
	/* Move the previous attachment down */
	IF @AttachmentGroupGUID IS NOT NULL
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) - 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID = @AttachmentGroupGUID AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
	ELSE 
		UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder + 1 WHERE AttachmentOrder = ((SELECT AttachmentOrder FROM CMS_AttachmentHistory WHERE AttachmentHistoryID = @AttachmentHistoryID) - 1 ) AND AttachmentDocumentID = @AttachmentDocumentID AND AttachmentGroupGUID IS NULL AND (AttachmentHistoryID IN (SELECT AttachmentHistoryID FROM CMS_VersionAttachment WHERE VersionHistoryID=@VersionHistoryID))
		
	/* Move the current attachment up */
	UPDATE CMS_AttachmentHistory SET AttachmentOrder = AttachmentOrder - 1 WHERE AttachmentHistoryID = @AttachmentHistoryID AND AttachmentOrder > 1
END
GO

-- B5822 Page template category didn't remove referencing value in cms_class column
DECLARE @QueryClassID int;
SELECT @QueryClassID=ClassID FROM CMS_Class WHERE ClassName = N'cms.pagetemplatecategory '
IF (@QueryClassID > 0) AND NOT EXISTS(SELECT QueryID FROM CMS_Query WHERE ClassID=@QueryClassID AND QueryName= N'removedependencies' )
BEGIN
INSERT INTO CMS_Query ([QueryName], [QueryTypeID], [QueryText], [QueryRequiresTransaction], [ClassID], [QueryIsLocked],
  [QueryLastModified], [QueryGUID], [QueryLoadGeneration], [QueryIsCustom] ) 
  VALUES ( 'removedependencies', 1, 'Proc_CMS_PageTemplateCategory_RemoveDependencies', 0, @QueryClassID, 0, GETDATE(), NEWID(), 0, 0)
END
GO

IF EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.ROUTINES WHERE [ROUTINE_NAME]= N'Proc_CMS_PageTemplateCategory_RemoveDependencies' AND [ROUTINE_TYPE]= N'PROCEDURE')
DROP PROCEDURE [Proc_CMS_PageTemplateCategory_RemoveDependencies]
GO

CREATE PROCEDURE [Proc_CMS_PageTemplateCategory_RemoveDependencies]
	@ID int
AS
BEGIN
	SET NOCOUNT ON;
	BEGIN TRANSACTION;
	-- CMS_Class
	UPDATE CMS_Class SET ClassPageTemplateCategoryID = NULL WHERE ClassPageTemplateCategoryID = @ID
	COMMIT TRANSACTION;
END
GO

-- B5820 Conversion values listed in AB tests with same name and same node were joined through multiple sites. (the same for MVT)
UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT ABTestID,ABTestName, ABTestDisplayName, ABTestSiteID,  ABTestCulture, ABTestOriginalPage, ABTestOpenFrom, ABTestOpenTo, ABTestEnabled, ABTestMaxConversions, ABTestConversions, ABTestTargetConversionType, SUM (HitsValue) AS HitsValue FROM OM_ABTest 
LEFT JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''abconversion;''+ ABTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_ABTest.ABTestSiteID
LEFT JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
GROUP BY ABTestName, ABTestDisplayName, ABTestID, ABTestCulture, ABTestOriginalPage, ABTestOpenFrom, ABTestOpenTo, ABTestEnabled, ABTestConversions, ABTestSiteID, ABTestMaxConversions, ABTestTargetConversionType) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectwithhits' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.ABTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, SUM (HitsValue) AS HitsValue,
   HitsStartTime,HitsEndTime, MVTestPage, MVTestMaxConversions, MVTestTargetConversionType  FROM OM_MVTest
LEFT JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
LEFT JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID
,HitsStartTime,HitsEndTime, MVTestMaxConversions, MVTestTargetConversionType
) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'selectwithhits' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_DayHits ON Analytics_Statistics.StatisticsID = Analytics_DayHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsDays' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_HourHits ON Analytics_Statistics.StatisticsID = Analytics_HourHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsHours' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO


UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_MonthHits ON Analytics_Statistics.StatisticsID = Analytics_MonthHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsMonths' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_WeekHits ON Analytics_Statistics.StatisticsID = Analytics_WeekHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsWeeks' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO


UPDATE CMS_Query
SET QueryText = 
'SELECT ##COLUMNS##
  FROM (SELECT MVTestName, MVTestDisplayName, MVTestSiteID, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, SUM(HitsCount) AS MVTestConversions, SUM (HitsValue) AS HitsValue
   FROM OM_MVTest
JOIN Analytics_Statistics ON Analytics_Statistics.StatisticsCode LIKE ''mvtconversion;''+ MVTestName+ '';%'' AND Analytics_Statistics.StatisticsSiteID = OM_MVTest.MVTestSiteID
JOIN Analytics_YearHits ON Analytics_Statistics.StatisticsID = Analytics_YearHits.HitsStatisticsID
WHERE HitsStartTime >= @From AND HitsEndTime <= @To
GROUP BY MVTestName, MVTestDisplayName, MVTestID, MVTestCulture, MVTestPage, MVTestOpenFrom, MVTestOpenTo, MVTestEnabled, MVTestConversions, MVTestSiteID

) AS X
WHERE ##WHERE## ORDER BY ##ORDERBY##'
WHERE QueryName = N'SelectWithHitsYears' AND ClassID = (SELECT ClassID FROM CMS_Class WHERE ClassName=N'OM.MVTest')
GO

-- B5878 - incorrect password form cotnrol for SQLDastaSource
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 9
BEGIN
	IF (SELECT UserControlID FROM CMS_FormUserControl WHERE UserControlCodeName = N'encryptedpassword') IS NOT NULL BEGIN
		UPDATE CMS_WebPart SET WebPartProperties = REPLACE(WebPartProperties, N'<settings><controlname>password</controlname></settings>', N'<settings><controlname>encryptedpassword</controlname></settings>') WHERE WebPartName = N'SQLDataSource'
	END
END 
GO

-- B5906 - slow loading of Newsletter issue list
IF NOT EXISTS (SELECT name FROM sys.indexes WHERE name = 'IX_OM_Activity_ActivityItemDetailID')
BEGIN
CREATE NONCLUSTERED INDEX IX_OM_Activity_ActivityItemDetailID ON OM_Activity
(
ActivityItemDetailID ASC
)
END
GO

-- B5730 - Chat.CreateNewRoom UI element has it's from version field set to 6.0 not 7.0
GO
UPDATE [CMS_UIElement]
SET [ElementFromVersion] = '7.0'
WHERE [ElementName] = 'Chat.CreateNewRoom' AND [ElementFromVersion] = '6.0'
GO


/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '11' WHERE KeyName = N'CMSHotfixVersion'
GO
