SET IDENTITY_INSERT [CMS_WorkflowStep] ON
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (1, N'Edit', N'edit', 1, 1, '633c6b94-f891-4a37-ba9c-bd14f76bcde8', '20120528 16:38:11', 2, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints />
  <Position>
    <X>0</X>
    <Y>0</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (2, N'Published', N'published', 4, 1, '4391d9e9-5954-41d0-b082-fef4b09bcff3', '20111003 13:54:21', 100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (20, N'Archived', N'archived', 5, 1, '9d987f6a-c420-49d8-aafd-898b7ec4ece9', '20111003 13:54:22', 101, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8028, N'Start', N'start', NULL, 514, 'b067ff09-8a33-4b7e-a57c-30261e8a18b3', '20120914 13:35:11', 1, 0, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="6049b3f1-d823-4ed0-a216-745e8ffc6647">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>200</X>
    <Y>2700</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8029, N'Finished', N'finished', NULL, 514, '518de414-f605-4f5b-84df-7069bcc3c214', '20120914 13:44:07', 99, 0, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints />
  <DefinitionPoint Guid="e75970a9-c88a-42dd-b45b-1628e4f5e9ec">
    <Label>Default</Label>
    <Type>0</Type>
    <StepRolesSecurity>0</StepRolesSecurity>
    <StepUsersSecurity>0</StepUsersSecurity>
  </DefinitionPoint>
  <Position>
    <X>2370</X>
    <Y>3090</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8030, N'Send eBook link', N'SendNewsletterIssue', NULL, 514, 'b77c3276-08a7-4919-a570-51f025155c90', '20120914 13:36:04', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="e4490faf-e22c-4d4b-8a8c-36a362034daa">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>430</X>
    <Y>2690</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 136, N'<Parameters><newsletterissue>1243eb4d-281f-4ff0-85e6-dc75c3561925</newsletterissue></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8031, N'Wait 1 day', N'Wait', NULL, 514, 'aab1592b-d8d6-4702-9d89-546a5b647c9b', '20120914 13:37:21', 10, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>true</TimeoutEnabled>
  <TimeoutInterval>minute;1/1/0001 12:00:00 AM;1;00:00:00;23:59:59.9999999;Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday</TimeoutInterval>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="9afb4de8-8693-4fa3-bc52-f26826f736b3">
      <Label>Default</Label>
      <Text />
      <Tooltip />
      <Condition />
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>650</X>
    <Y>2690</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8032, N'If downloaded eBook', N'Condition', NULL, 514, 'd1a58fbe-bc0a-4a46-98cd-5e10ca41d52b', '20120916 02:54:21', 6, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint xsi:type="ConditionSourcePoint" Guid="1e3ae383-99aa-49a2-869e-14e5f5c413e6">
      <Label>If match</Label>
      <Text />
      <Tooltip />
      <Condition>{%Rule("Contact.VisitedPage(\"/Free-eBook/How-to-Choose-Your-Dream-Coffee-Machine\", ToInt(1))|(user)administrator|(hash)f9f6175dca92ab017bf154fefc8613af56394c3c357f84ee44edf2827c84c271", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"CMSContactHasDownloadedSpecifiedFileInLastXDays\" &gt;&lt;p n=\"item\"&gt;&lt;t&gt;/Free-eBook/How-to-Choose-Your-Dream-Coffee-Machine&lt;/t&gt;&lt;v&gt;/Free-eBook/How-to-Choose-Your-Dream-Coffee-Machine&lt;/v&gt;&lt;r&gt;true&lt;/r&gt;&lt;d&gt;select file&lt;/d&gt;&lt;/p&gt;&lt;p n=\"_perfectum\"&gt;&lt;t&gt;has&lt;/t&gt;&lt;v&gt;&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;select operation&lt;/d&gt;&lt;/p&gt;&lt;p n=\"days\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;enter days&lt;/d&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</Condition>
      <Type>1</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
    <SourcePoint xsi:type="ElseSourcePoint" Guid="160a0bcb-47c1-4a1c-baad-6d0a4aa025c2">
      <Label>Else</Label>
      <Type>2</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>860</X>
    <Y>2700</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8033, N'Send eBook reminder', N'SendNewsletterIssue_1', NULL, 514, 'f1749b35-6307-4d75-a252-14acf2e3119a', '20120914 13:38:08', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="5be336c2-6f4d-4be4-a831-4a2225e3864c">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>870</X>
    <Y>2840</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 136, N'<Parameters><newsletterissue>707d1994-333a-4efe-866b-d4ef90cdbb42</newsletterissue></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8034, N'Wait 1 week', N'Wait_1', NULL, 514, 'bd75d963-f3a6-4abb-b44e-1251d6a0ad36', '20120914 13:38:26', 10, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>true</TimeoutEnabled>
  <TimeoutInterval>minute;1/1/0001 12:00:00 AM;1;00:00:00;23:59:59.9999999;Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday</TimeoutInterval>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="7612e4a9-5b04-48cf-9209-40fc0b91cd34">
      <Label>Default</Label>
      <Text />
      <Tooltip />
      <Condition />
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1160</X>
    <Y>2720</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8035, N'Send tips to choose coffee', N'SendNewsletterIssue_2', NULL, 514, '97674532-4627-4e8d-be20-76bc8ec739f7', '20120914 14:11:24', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="46b5875f-55c4-417e-8c98-8a87da918eee">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1360</X>
    <Y>2720</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 136, N'<Parameters><newsletterissue>7e23da70-22fe-489b-851c-54be913831d3</newsletterissue></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8036, N'Wait 1 week', N'Wait_2', NULL, 514, 'eff83c91-9e25-433c-9aa8-88a646676e8e', '20120914 13:42:05', 10, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>true</TimeoutEnabled>
  <TimeoutInterval>minute;1/1/0001 12:00:00 AM;1;00:00:00;23:59:59.9999999;Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday</TimeoutInterval>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="97234dff-b034-4892-99c6-a265c07e7620">
      <Label>Default</Label>
      <Text />
      <Tooltip />
      <Condition />
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1640</X>
    <Y>2720</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8037, N'If opened&clicked link in last e-mail', N'Condition_1', NULL, 514, 'e0a599d4-5624-43f6-835b-d6b12b558a65', '20120916 02:56:45', 6, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint xsi:type="ConditionSourcePoint" Guid="10dcc1eb-46a0-4e10-a35b-6e3f4c040b52">
      <Label>If match</Label>
      <Text />
      <Tooltip />
      <Condition>{%Rule("(Contact.OpenedNewsletterIssue(\"7e23da70-22fe-489b-851c-54be913831d3\", ToInt(7)) &amp;&amp; Contact.ClickedLinkInNewsletterIssue(\"7e23da70-22fe-489b-851c-54be913831d3\", ToInt(7))) || Contact.VisitedPage(\"/7-Tips-How-to-Choose-the-Best-Coffee\", ToInt(7))|(user)administrator|(hash)8e65990644f911fb14622a9073feb356d7770ab0f9dfda45218b3790939bc2d4", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" /&gt;&lt;r pos=\"0\" par=\"0\" op=\"and\" n=\"CMSContactHasOpenedSpecifiedNewsletterIssueInTheLastXDays\" &gt;&lt;p n=\"days\"&gt;&lt;t&gt;7&lt;/t&gt;&lt;v&gt;7&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;enter text&lt;/d&gt;&lt;/p&gt;&lt;p n=\"issue\"&gt;&lt;t&gt;7 Tips How to Choose the Best Coffee&lt;/t&gt;&lt;v&gt;7e23da70-22fe-489b-851c-54be913831d3&lt;/v&gt;&lt;r&gt;true&lt;/r&gt;&lt;d&gt;select newsletter issue&lt;/d&gt;&lt;/p&gt;&lt;p n=\"_perfectum\"&gt;&lt;t&gt;has&lt;/t&gt;&lt;v&gt;&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;select operation&lt;/d&gt;&lt;/p&gt;&lt;/r&gt;&lt;r pos=\"1\" par=\"0\" op=\"and\" n=\"CMSContactHasClickedALinkInNewsletterIssueInLastXDays\" &gt;&lt;p n=\"days\"&gt;&lt;t&gt;7&lt;/t&gt;&lt;v&gt;7&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;enter days&lt;/d&gt;&lt;/p&gt;&lt;p n=\"issue\"&gt;&lt;t&gt;7 Tips How to Choose the Best Coffee&lt;/t&gt;&lt;v&gt;7e23da70-22fe-489b-851c-54be913831d3&lt;/v&gt;&lt;r&gt;true&lt;/r&gt;&lt;d&gt;select newsletter issue&lt;/d&gt;&lt;/p&gt;&lt;p n=\"_perfectum\"&gt;&lt;t&gt;has&lt;/t&gt;&lt;v&gt;&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;select operation&lt;/d&gt;&lt;/p&gt;&lt;/r&gt;&lt;r pos=\"1\" par=\"\" op=\"or\" n=\"CMSContactHasVisitedSpecifiedPageInLastXDays\" &gt;&lt;p n=\"item\"&gt;&lt;t&gt;/7-Tips-How-to-Choose-the-Best-Coffee&lt;/t&gt;&lt;v&gt;/7-Tips-How-to-Choose-the-Best-Coffee&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;select page&lt;/d&gt;&lt;/p&gt;&lt;p n=\"_perfectum\"&gt;&lt;t&gt;has&lt;/t&gt;&lt;v&gt;&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;select operation&lt;/d&gt;&lt;/p&gt;&lt;p n=\"days\"&gt;&lt;t&gt;7&lt;/t&gt;&lt;v&gt;7&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;enter days&lt;/d&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</Condition>
      <Type>1</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
    <SourcePoint xsi:type="ElseSourcePoint" Guid="6ff314e7-8165-4fee-b4c9-7c1e815b0bf3">
      <Label>Else</Label>
      <Type>2</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1870</X>
    <Y>2730</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8038, N'Send special offer', N'SendNewsletterIssue_3', NULL, 514, '114d1144-ad74-49cf-9fc4-b0ec1052721f', '20120914 13:43:12', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="d0d50337-2d4e-437b-977f-5ef07c8bdfcc">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>2260</X>
    <Y>2720</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 136, N'<Parameters><newsletterissue>3e4e838e-cfc4-4748-bfd7-9cda8063d4b9</newsletterissue></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8039, N'Wait 1 week', N'Wait_3', NULL, 514, 'f2658e34-3d2d-4d13-8edd-8e76e8b406af', '20120914 13:44:04', 10, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>true</TimeoutEnabled>
  <TimeoutInterval>minute;1/1/0001 12:00:00 AM;1;00:00:00;23:59:59.9999999;Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday</TimeoutInterval>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="4bb58130-8e52-45dd-a652-e55c89532210">
      <Label>Default</Label>
      <Text />
      <Tooltip />
      <Condition />
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>2510</X>
    <Y>2730</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8040, N'If purchased something', N'Condition_2', NULL, 514, '9f30f03b-3d2d-4fc4-88d4-40344149f55a', '20120914 13:44:42', 6, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint xsi:type="ConditionSourcePoint" Guid="df339a9a-67ff-4899-a8d5-c931e57fa81d">
      <Label>If match</Label>
      <Text />
      <Tooltip />
      <Condition>{%Rule("Contact.PurchasedNumberOfProducts(ToInt(1), ToInt(7))|(user)administrator|(hash)686c08def45774d90db4eaa090f10f5f5a4e76bf92ab4e859e24d41045221f34", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"CMSContactHasPurchasedNumberOfProductsInTheLastXDays\" &gt;&lt;p n=\"days\"&gt;&lt;t&gt;7&lt;/t&gt;&lt;v&gt;7&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;enter days&lt;/d&gt;&lt;/p&gt;&lt;p n=\"_perfectum\"&gt;&lt;t&gt;has&lt;/t&gt;&lt;v&gt;&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;select operation&lt;/d&gt;&lt;/p&gt;&lt;p n=\"num\"&gt;&lt;t&gt;1&lt;/t&gt;&lt;v&gt;1&lt;/v&gt;&lt;r&gt;true&lt;/r&gt;&lt;d&gt;enter number&lt;/d&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</Condition>
      <Type>1</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
    <SourcePoint xsi:type="ElseSourcePoint" Guid="b58a1c12-458b-49f3-8571-a88a651c5d42">
      <Label>Else</Label>
      <Type>2</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>2780</X>
    <Y>2780</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8041, N'Send e-mail to sales dpt.', N'SendE-mail', NULL, 514, '601e26c6-7b9d-468f-b3c1-e3ee1f51d01f', '20120916 02:46:42', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="3e58b446-5f9f-43b0-bad7-1d7071376f88">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>2860</X>
    <Y>2940</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 96, N'<Parameters><to>sales@localhost.local</to><emailtemplate></emailtemplate><basedon>1</basedon><subject>Customer for FUP</subject><body>&lt;div style="text-align: left;"&gt;
	&lt;span style="font-size:14px;"&gt;The following customer may be interested, but haven&amp;rsquo;t purchased anything yet. Please follow up with him/her:&lt;/span&gt;&lt;br /&gt;
	&amp;nbsp;&lt;/div&gt;
&lt;div style="text-align: left;"&gt;
	&lt;span style="font-size:14px;"&gt;First name: {% Contact.ContactFirstName |(user)administrator|(hash)d7de635fbf49c0808ac01e7de0e8ef6c84bf65756a2926fbd2f3b835545761f6%}&lt;br /&gt;
	Last name: {% Contact.ContactLastName |(user)administrator|(hash)aebf11db91de24e194644685e63e2863ecb9741bae036d9ab4dd1b6f5d23735d%}&lt;br /&gt;
	E-mail: {% Contact.ContactEmail |(user)administrator|(hash)afb9856b9709b351ea2098c3aab3e049b673364c3de01be64e8e20ea06d89550%}&lt;br /&gt;
	Phone: {% Contact.ContactMobilePhone |(user)administrator|(hash)8e30d0ad87a7cc88af2594059722ced5894e34251aaa6bafdce6b192b5044bce%}&lt;/span&gt;&lt;br /&gt;
	&amp;nbsp;&lt;/div&gt;
</body><from>marketing@localhost.local</from></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (8042, N'Newsletter subscription', N'NewsletterSubscription', NULL, 514, '2e478169-5af2-4cb0-b52f-4c8b216daafc', '20120914 14:22:29', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="407cceab-2e73-4483-a415-2ecd4719d3ef">
      <Label>Default</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>2800</X>
    <Y>3100</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 140, N'<Parameters><action>0</action><newslettername>MonthlyNewsletter</newslettername></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5879, N'Edit', N'edit', NULL, 212, '60290d0b-ea07-4c0f-98b2-36b092a4f8b0', '20120614 17:21:18', 2, 0, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="70204426-8569-464d-a2a5-7d062d4bd9e9">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>230</X>
    <Y>2670</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5880, N'Published', N'published', NULL, 212, '4d346d84-a8af-4333-bef9-dd6bd84a9fd3', '20120614 17:21:11', 100, NULL, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="06e97b54-c45d-4225-ba7b-4c52676288ad">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>770</X>
    <Y>2680</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5881, N'Archived', N'archived', NULL, 212, '82696a71-5ddb-4eaf-9b0a-330a04d9eb18', '20120614 17:21:13', 101, 0, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="ce7750ac-6481-4993-976f-20940f253fd3">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>930</X>
    <Y>2680</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5882, N'Send for translation', N'Send_for_translation', NULL, 212, 'b8a60f49-6d78-457d-8d84-a2c667c49d83', '20120709 08:58:17', 11, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="c71a1655-295d-4194-a751-910387cdbbd0">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>550</X>
    <Y>2650</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 52, N'<Parameters><servicename>ManualTranslation</servicename><targetlanguage>en-US</targetlanguage><processbinary>False</processbinary><instructions></instructions><deadline>7;day</deadline><priority>1</priority></Parameters>')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5883, N'Approval', N'Standard', 47, 212, '64450a8e-550d-448f-9bfd-8a56c04c6336', '20120614 17:21:16', 3, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutInterval />
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="9999619f-e6c0-47ab-968c-34a419b7186f">
      <Label>Standard</Label>
      <Text>Send for translation and publish</Text>
      <Tooltip>Sends the document for translation to the target languages and publishes this document.</Tooltip>
      <Condition />
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>390</X>
    <Y>2670</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5869, N'Edit', N'edit', NULL, 211, '5f104454-f5a2-4f02-ade9-de782987c275', '20120614 17:21:37', 2, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>true</TimeoutEnabled>
  <TimeoutInterval>minute;1/1/0001 12:00:00 AM;1;00:00:00;23:59:59.9999999;Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday</TimeoutInterval>
  <TimeoutTarget>feb7e072-bac9-4179-a122-9775791e343e</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="bfc73cd2-35bc-48d7-9bfb-804967b646ef">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
    <SourcePoint xsi:type="TimeoutSourcePoint" Guid="feb7e072-bac9-4179-a122-9775791e343e">
      <Label>Timeout</Label>
      <Type>3</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>220</X>
    <Y>2600</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5870, N'Published', N'published', NULL, 211, '491a9e56-ef97-4430-8ff1-184cde7022ae', '20120614 17:23:36', 100, NULL, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="8c087fa0-3f27-4381-983c-8bce419c967e">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1220</X>
    <Y>2610</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5871, N'Archived', N'archived', NULL, 211, '49c0826d-4cec-498e-8e9f-ab5c24f69740', '20120614 17:23:39', 101, 0, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="742ffb8d-80d9-46be-a493-04b9dc901162">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1380</X>
    <Y>2610</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5873, N'Import translation', N'Import_translation', NULL, 211, '626df3e9-b68a-42a5-9e05-74ec45e1f2aa', '20120614 17:23:25', 11, NULL, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="271ec955-2630-4a0d-8070-2aa30db80065">
      <Label>Standard</Label>
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>1020</X>
    <Y>2600</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 53, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5874, N'Translation ready condition', N'Condition', NULL, 211, '0d4cea79-abcc-4a0c-a332-a24b42753a0e', '20120614 17:23:15', 6, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>false</TimeoutEnabled>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint xsi:type="ConditionSourcePoint" Guid="07001585-607e-4115-9ccf-90cdbd4c05a6">
      <Label>If translation is ready</Label>
      <Text>Import translation</Text>
      <Tooltip>If translation is ready, the document will be translated.</Tooltip>
      <Condition>{%Document.IsTranslationReady()|(user)administrator|(hash)997057ef82241efefa94a17c05b732d8ea5385154b8d65c57a9153534f9db8aa%}</Condition>
      <Type>1</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
    <SourcePoint xsi:type="ElseSourcePoint" Guid="7c1a3c8d-093c-4b93-bc7e-3f68ce3e1f1a">
      <Label>Else</Label>
      <Type>2</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>710</X>
    <Y>2600</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (5877, N'Wait 1 day', N'Wait', NULL, 211, '71b91db5-72c1-489c-9a87-b9825d0adbad', '20120615 07:32:26', 10, 1, N'<?xml version="1.0" encoding="utf-16"?>
<Step xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <TimeoutEnabled>true</TimeoutEnabled>
  <TimeoutInterval>day;1/1/0001 12:00:00 AM;1;Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday</TimeoutInterval>
  <TimeoutTarget>00000000-0000-0000-0000-000000000000</TimeoutTarget>
  <SourcePoints>
    <SourcePoint Guid="da4480cb-cfdd-481e-a1a2-5c2b98e478f3">
      <Label>Standard</Label>
      <Text />
      <Tooltip />
      <Condition />
      <Type>0</Type>
      <StepRolesSecurity>0</StepRolesSecurity>
      <StepUsersSecurity>0</StepUsersSecurity>
    </SourcePoint>
  </SourcePoints>
  <Position>
    <X>440</X>
    <Y>2600</Y>
  </Position>
</Step>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, N'')
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (254, N'Edit', N'edit', 1, 46, '6d3da94a-c830-408a-9738-65bf1c593551', '20100907 10:37:52', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (255, N'Published', N'published', 2, 46, '931aa2e0-ae9d-4cd4-a07c-c01bd6dd4080', '20100907 10:37:52', 100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
INSERT INTO [CMS_WorkflowStep] ([StepID], [StepDisplayName], [StepName], [StepOrder], [StepWorkflowID], [StepGUID], [StepLastModified], [StepType], [StepAllowReject], [StepDefinition], [StepRolesSecurity], [StepUsersSecurity], [StepApprovedTemplateName], [StepRejectedTemplateName], [StepReadyforApprovalTemplateName], [StepSendApproveEmails], [StepSendRejectEmails], [StepSendReadyForApprovalEmails], [StepSendEmails], [StepAllowPublish], [StepActionID], [StepActionParameters]) VALUES (256, N'Archived', N'archived', 3, 46, '8750289f-6686-4aa3-825c-b3cb89644fea', '20100907 10:37:52', 101, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
SET IDENTITY_INSERT [CMS_WorkflowStep] OFF
