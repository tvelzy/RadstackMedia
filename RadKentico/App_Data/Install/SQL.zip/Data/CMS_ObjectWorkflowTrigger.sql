SET IDENTITY_INSERT [CMS_ObjectWorkflowTrigger] ON
SET IDENTITY_INSERT [CMS_ObjectWorkflowTrigger] OFF
